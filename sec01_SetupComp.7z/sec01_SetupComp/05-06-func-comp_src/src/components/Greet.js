import React from 'react';

const Greet = () => {
    return <h1>Hello Peter</h1>
}

export default Greet;