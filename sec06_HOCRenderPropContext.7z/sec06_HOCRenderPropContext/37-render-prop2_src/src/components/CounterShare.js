import React, { Component } from 'react'

class CounterShare extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             message: 'Peter1',
             count: 0,
             count2: 1
        }
    }
    incrementCount = () => {
        this.setState (prevState => {
            return { count : prevState.count + 1}
        })
    }
    // render() {
    //     return (
    //         <div>
    //             { this.props.children(this.state.count, this.incrementCount) }
    //         </div>
    //     )
    // }
    render() {
        return (
            <div>
                { this.props.render(this.state.count, this.incrementCount) }
            </div>
        )
    }
}

export default CounterShare
