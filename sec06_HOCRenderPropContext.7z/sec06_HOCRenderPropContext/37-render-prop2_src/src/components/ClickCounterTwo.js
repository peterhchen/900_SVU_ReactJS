import React, { Component } from 'react'

export class ClickCounterTwo extends Component {
    render() {
        const { count, incrementCount } = this.props
        return (
            <div>
                <button onClick={incrementCount}>Click { count } times </button>
            </div>
        )
    }
        
    // constructor(props) {
    //     super(props)
    
    //     this.state = {
    //          message: 'Peter1',
    //          count: 0,
    //          count2: 1
    //     }
    // }
    // incrementCount = () => {
    //     this.setState (prevState => {
    //         return { count : prevState.count + 1}
    //     })
    // }
    // render() {
    //     const { count } = this.state
    //     console.log ('this.state: ', this.state)
    //     // this.state: { message: "Peter1", count: 0 }
    //     console.log ('count: ', count)
    //     // count: 0
    //     return (
    //         <div>
    //             <button onClick={this.incrementCount}>Click { this.state.count } times </button>
    //             {/* <br />
    //              <button onClick={this.incrementCount}>Click { count } times </button>
    //             */}
    //         </div>
    //     )
    // }
}

export default ClickCounterTwo
