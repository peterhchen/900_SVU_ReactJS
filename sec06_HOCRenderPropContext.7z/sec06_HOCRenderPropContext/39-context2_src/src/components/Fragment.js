import React from 'react'

function Fragment() {
    return (
       <React.Fragment>
            <h1>
                Fragment Example
            </h1>
            <p>Description of Fragment</p>
        </React.Fragment> 
        // <div>
        //     <h1>
        //     Fragment Example
        //     </h1>
        //     <p>Description of Fragment</p>
        // </div>
    )
}

export default Fragment
