import React from 'react'
import { useSelector,useDispatch } from 'react-redux'
// import { buyCake } from '../redux/index'
// from '../redux' contains all the files and folders under '../index'
import { buyCake } from '../redux'

function HooksCakeContainer() {
    const numOfCakes = useSelector (state => state.numOfCakes)
    const dispatch = useDispatch ()
    return (
        <div>
            <h1>React/Redux Hooks - Number of Cake: { numOfCakes } </h1>
            <button onClick = { () => dispatch (buyCake()) }>React/Redux Hooks: Buy Cake</button>
        </div>
    )
}

export default HooksCakeContainer
