import React, { Component } from 'react'

class User extends Component {
    render() {
        return (
            <div>
                {/* Peter */}
                {/* { this.props.name } */ }
                {/* { this.props.name() } */ }
                {/* { this.props.name (false) } */}
                { this.props.render (true) } 
            </div>
        )
    }
}

export default User
