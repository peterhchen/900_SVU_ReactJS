import React, { Component } from 'react';
import './App.css';
import ClickCounterTwo from './components/ClickCounterTwo';
import HoverCounterTwo from './components/HoverCounterTwo';
import User from './components/User';
import CounterShare from './components/CounterShare';

class App extends Component {
  render () {
    return (
      <div className="App">
        {/*
          <h1>Peter</h1>
          <ClickCounterTwo />
          <HoverCounterTwo />
        */}
        {/*  <User name='Peter' /> */}
        {/* <User name={ () => 'Peter' } /> */ }
        {/* <User name = { (isLoggedIn) => isLoggedIn ? 'Peter': 'Guest' } /> */ }
        <User render = { (isLoggedIn) => isLoggedIn ? 'Peter': 'Guest' } />
        {/*
        <CounterShare>
          {(count, incrementCount) => ( 
            <ClickCounterTwo count = { count } incrementCount = { incrementCount } />
          )}
        </CounterShare> 
        */}
        
        <CounterShare 
          render = { (count, incrementCount) => ( 
            <ClickCounterTwo count = { count } incrementCount = { incrementCount } />
          )}
        />
        
        <CounterShare 
          render = { (count, incrementCount) => ( 
            <HoverCounterTwo count = { count } incrementCount = { incrementCount } />
          )}
        />
      </div>
    );
  }
}

export default App;
