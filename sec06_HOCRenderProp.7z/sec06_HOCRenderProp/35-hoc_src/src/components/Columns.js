import React from 'react'

function Columns() {
    return (
        <React.Fragment>
            <td>Name</td>
            <td>id</td>
        </React.Fragment>
    
        // <div>
        //     <td>Name</td>
        //     <td>id</td>
        // </div>
    )
}

export default Columns
