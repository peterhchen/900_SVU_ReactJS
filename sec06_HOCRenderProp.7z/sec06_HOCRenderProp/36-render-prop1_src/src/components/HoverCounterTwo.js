import React, { Component } from 'react'

class HoverCounterTwo extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             message: 'Peter1',
             count: 0,
             count2: 1
        }
    }
    incrementCount = () => {
        this.setState (prevState => {
            return { count : prevState.count + 1}
        })
    }
    render() {
        const { count } = this.state
        return (
            <div>
                <h2 onMouseOver = { this.incrementCount }>Hover { count} Times</h2>
            </div>
        )
    }
}

export default HoverCounterTwo
